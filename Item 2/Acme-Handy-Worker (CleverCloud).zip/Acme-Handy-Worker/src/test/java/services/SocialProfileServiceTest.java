
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Actor;
import domain.SocialProfile;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class SocialProfileServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private SocialProfileService	socialProfileService;

	@Autowired
	private ActorService			actorService;


	//Test
	@Test
	public void testCreateSocialProfile() {
		//Setting up the authority to execute services.
		this.authenticate("customer1");

		//Using create() to initialise a new entity. 
		final SocialProfile socialProfile = this.socialProfileService.create();

		socialProfile.setNick("TestNick");
		socialProfile.setSocialNetwork("https://www.instagram.com/");
		socialProfile.setProfileLink("https://www.testlink.com/");

		//Saving entity to database and confirming it exists with findAll().
		final SocialProfile saved = this.socialProfileService.save(socialProfile);
		final SocialProfile bbdd = this.socialProfileService.findOne(saved.getId());
		Assert.notNull(bbdd);

	}

	@Test
	public void testListDeleteSocialProfile() {
		//Setting up the authority to execute services.
		this.authenticate("handyWorker1");

		//We retrieve a list of all socialProfiles, and obtain the Id of one of them.
		final Actor actor = this.actorService.findByPrincipal();
		actor.getSocialProfiles().iterator().next().getId();
		final int id = actor.getSocialProfiles().iterator().next().getId();

		//Using findOne() to retrieve a particular entity and verifying it.
		final SocialProfile socialProfile = this.socialProfileService.findOne(id);
		Assert.notNull(id);

		//Using delete() to delete the entity we retrieved.
		this.socialProfileService.delete(socialProfile);

		//Verifying the entity has been removed from the database.
		final SocialProfile bbdd = this.socialProfileService.findOne(socialProfile.getId());
		Assert.isNull(bbdd);
	}
}
