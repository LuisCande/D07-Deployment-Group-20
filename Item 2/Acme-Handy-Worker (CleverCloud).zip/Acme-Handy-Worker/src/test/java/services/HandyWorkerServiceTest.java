
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Actor;
import domain.HandyWorker;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class HandyWorkerServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private HandyWorkerService	handyWorkerService;

	@Autowired
	private EndorsementService	endorsementService;

	@Autowired
	private ActorService		actorService;


	//Tests

	@Test
	public void testCreateHandyWorker() {

		//Setting up the authority to execute services.

		//Using create() to initialise a new entity. Necessary Id's taken from populated database.

		final HandyWorker handyWorker = this.handyWorkerService.create();

		handyWorker.setName("Curro");
		handyWorker.setSurname("Paquito");
		handyWorker.setEmail("Fran cisc co <currmaror@alum.us.es>");
		handyWorker.setPhone("654888444");
		handyWorker.setAddress("C/ Manzanilla 32");
		handyWorker.getUserAccount().setUsername("CASOL");
		handyWorker.getUserAccount().setPassword("12345678");

		final HandyWorker saved = this.handyWorkerService.save(handyWorker);
		final HandyWorker bbdd = this.handyWorkerService.findOne(saved.getId());
		Assert.notNull(bbdd);
	}

	@Test
	public void testComputeScore() {

		//Setting up the authority to execute services.
		this.authenticate("admin");
		final Actor a = this.actorService.findOne(8576);
		final HandyWorker hw = (HandyWorker) a;
		this.endorsementService.computeScore(a);

		Assert.isTrue(hw.getScore() != null);
	}
}
