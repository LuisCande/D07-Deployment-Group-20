
package services;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Referee;
import domain.Report;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class ReportServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private ReportService	reportService;

	@Autowired
	private ActorService	actorService;

	@Autowired
	private RefereeService	refereeService;


	//Tests

	@Test
	public void testCreateListReport() {

		//Setting up the authority to execute services.

		this.authenticate("referee1");

		//Using create() to initialise a new entity. Necessary Id's taken from populated database.

		final Report report = this.reportService.create(8703);//Id from complaint3
		//		final Referee r = (Referee) this.actorService.findByPrincipal();
		//		final ProfessionalRecord professionalRecord = this.professionalRecordService.create(hw.getCurriculum().getId());//Id from curriculum1

		final Date moment = new GregorianCalendar(2015, Calendar.DECEMBER, 15).getTime();

		report.setAttachments("https://www.att.com/");
		report.setDescription("description");
		report.setMoment(moment);
		//Saving entity to database and confirming it exists with findAll().
		final Report saved = this.reportService.save(report, false);

		final Collection<Report> reports = this.reportService.findAll();
		Assert.isTrue(reports.contains(saved));
	}

	@Test
	public void testDeleteReport() {
		//Setting up the authority to execute services.
		this.authenticate("referee2");

		//We retrieve a list of all PersonalRecords, and obtain the Id of one of them.
		final int refereeId = this.actorService.findByPrincipal().getId();
		final Referee referee = this.refereeService.findOne(refereeId);
		final Collection<Report> reports = referee.getReports();
		final Report report = this.reportService.findOne(8718); //id report4 (con referee2, finalMode=false)
		//Using findOne() to retrieve a particular entity and verifying it.
		Assert.notNull(report);

		//Using delete() to delete the entity we retrieved.
		this.reportService.delete(report);

		//Verifying the entity has been removed from the database.
		final Report bbdd = this.reportService.findOne(report.getId());
		Assert.isTrue(!reports.contains(bbdd));
	}
}
