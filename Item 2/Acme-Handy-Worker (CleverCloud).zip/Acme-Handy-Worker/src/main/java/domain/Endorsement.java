
package domain;

import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
public class Endorsement extends DomainEntity {

	//Attributes

	private Date		moment;
	private String		comments;
	private Boolean		customerToHandy;

	//Relationships

	private HandyWorker	handyWorker;
	private Customer	customer;


	//Getters

	@NotNull
	@Past
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	public Date getMoment() {
		return this.moment;
	}

	@NotBlank
	public String getComments() {
		return this.comments;
	}

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public HandyWorker getHandyWorker() {
		return this.handyWorker;
	}

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Customer getCustomer() {
		return this.customer;
	}

	@NotNull
	public Boolean getCustomerToHandy() {
		return this.customerToHandy;
	}

	//Setters

	public void setMoment(final Date moment) {
		this.moment = moment;
	}

	public void setComments(final String comments) {
		this.comments = comments;
	}

	public void setHandyWorker(final HandyWorker handyWorker) {
		this.handyWorker = handyWorker;
	}

	public void setCustomer(final Customer customer) {
		this.customer = customer;
	}

	public void setCustomerToHandy(final Boolean customerToHandy) {
		this.customerToHandy = customerToHandy;
	}

}
