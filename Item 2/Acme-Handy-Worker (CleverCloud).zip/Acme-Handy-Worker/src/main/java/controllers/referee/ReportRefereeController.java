
package controllers.referee;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.ComplaintService;
import services.ReportService;
import controllers.AbstractController;
import domain.Complaint;
import domain.Referee;
import domain.Report;

@Controller
@RequestMapping("report/referee")
public class ReportRefereeController extends AbstractController {

	//Services

	@Autowired
	private ReportService		reportService;

	@Autowired
	private ComplaintService	complaintService;

	@Autowired
	private ActorService		actorService;


	//Listing

	@RequestMapping(value = "/listAll", method = RequestMethod.GET)
	public ModelAndView listAll() {
		final ModelAndView result;
		Collection<Report> reports;

		final Referee r = (Referee) this.actorService.findByPrincipal();

		reports = r.getReports();

		result = new ModelAndView("report/list");
		result.addObject("reports", reports);
		result.addObject("requestURI", "report/referee/list.do");

		return result;
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(@RequestParam final int complaintId) {
		final ModelAndView result;
		Collection<Report> reports;

		final Complaint complaint = this.complaintService.findOne(complaintId);
		if (complaint.getReferee() != null)
			if (complaint.getReferee().getId() != this.actorService.findByPrincipal().getId())
				return new ModelAndView("redirect:/welcome/index.do");

		reports = complaint.getReports();

		result = new ModelAndView("report/list");
		result.addObject("reports", reports);
		result.addObject("requestURI", "report/referee/list.do");

		return result;
	}
	//Creation

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int complaintId) {
		final ModelAndView result;
		Report report;

		report = this.reportService.create(complaintId);
		result = this.createEditModelAndView(report);

		return result;
	}

	//Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int reportId) {
		final ModelAndView result;
		Report report;

		report = this.reportService.findOne(reportId);
		Assert.notNull(report);
		result = this.createEditModelAndView(report);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Report report, final BindingResult binding) {
		ModelAndView result;
		final Referee r = (Referee) this.actorService.findByPrincipal();

		if (binding.hasErrors())
			result = this.createEditModelAndView(report);
		else
			try {
				final Complaint c = report.getComplaint();

				if (c.getReferee() == null) {
					c.setReferee(r);
					this.complaintService.saveFromReport(c);
				}
				if (report.getFinalMode() == true) {
					report.setFinalMode(false);
					this.reportService.save(report, true);
				} else
					this.reportService.save(report, false);

				result = new ModelAndView("redirect:/welcome/index.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(report, "report.commit.error");
			}
		return result;
	}

	//Display

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int reportId) {
		final ModelAndView result;

		final Report report = this.reportService.findOne(reportId);
		Assert.notNull(report);

		result = new ModelAndView("report/display");
		result.addObject("report", report);
		result.addObject("requestURI", "report/referee/display.do");

		return result;
	}

	//Delete 
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int reportId) {
		ModelAndView result;
		Collection<Report> reports;
		Report report;
		report = this.reportService.findOne(reportId);
		final Complaint c = report.getComplaint();

		result = new ModelAndView("report/list");

		reports = c.getReports();
		try {
			if (!report.getNotes().isEmpty())
				result = this.createEditModelAndView(report, "report.noteDelete.error");
			else {
				this.reportService.delete(report);
				reports = c.getReports();

				result.addObject("reports", reports);
				result.addObject("requestURI", "report/referee/listAll.do");
			}
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(report, "report.delete.error");
		}

		return result;
	}

	//Delete POST

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Report report, final BindingResult binding) {
		ModelAndView result;

		if (!report.getNotes().isEmpty())
			result = this.createEditModelAndView(report, "report.noteDelete.error");
		else
			try {
				this.reportService.delete(report);
				result = new ModelAndView("redirect:/report/referee/listAll.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(report, "report.delete.error");
			}
		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Report report) {
		ModelAndView result;

		result = this.createEditModelAndView(report, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Report report, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("report/edit");
		result.addObject("report", report);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "report/referee/edit.do");

		return result;

	}

}
