
package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.CategoryService;
import domain.Category;

@Controller
@RequestMapping("category")
public class CategoryController extends AbstractController {

	//Services

	@Autowired
	private CategoryService	categoryService;


	//Display

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView display() {
		ModelAndView result;
		final Collection<Category> categories = this.categoryService.findAll();

		result = new ModelAndView("category/list");
		result.addObject("categories", categories);
		result.addObject("requestURI", "categories/list.do");

		return result;
	}

	@RequestMapping(value = "/childrenList", method = RequestMethod.GET)
	public ModelAndView childrenList(@RequestParam final int categoryId) {
		final ModelAndView result;
		Collection<Category> categories;
		Category category;

		category = this.categoryService.findOne(categoryId);
		categories = category.getChildren();

		result = new ModelAndView("category/childrenList");
		result.addObject("categories", categories);
		result.addObject("requestURI", "category/childrenList.do");

		return result;
	}

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int categoryId) {
		ModelAndView result;
		Category category;

		category = this.categoryService.findOne(categoryId);

		result = new ModelAndView("category/display");
		result.addObject("category", category);
		result.addObject("requestURI", "category/display.do");

		return result;
	}
}
