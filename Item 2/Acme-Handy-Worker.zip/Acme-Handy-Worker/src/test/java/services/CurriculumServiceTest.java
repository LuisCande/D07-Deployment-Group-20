
package services;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Curriculum;
import domain.HandyWorker;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class CurriculumServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private CurriculumService	curriculumService;

	@Autowired
	private HandyWorkerService	handyWorkerService;


	//Tests

	@Test
	public void testCreateCurriculum() {
		//Creando un handyWorker que no tenga curriculum
		final HandyWorker hw = this.handyWorkerService.create();

		hw.setName("Curro");
		hw.setSurname("Paquito");
		hw.setEmail("Fran cisc co <currmaror@alum.us.es>");
		hw.setPhone("654888444");
		hw.setAddress("C/ Manzanilla 32");
		hw.getUserAccount().setUsername("handy1");
		hw.getUserAccount().setPassword("12345678");

		this.handyWorkerService.save(hw);

		this.authenticate("handy1");

		//Using create() to initialise a new entity. Necessary Id's taken from populated database.
		final Curriculum curriculum = this.curriculumService.create();

		//Saving entity to database and confirming it exists with findAll().		
		final Curriculum saved = this.curriculumService.save(curriculum);
		final Curriculum bbdd = this.curriculumService.findOne(saved.getId());
		Assert.notNull(bbdd);
	}

	@Test
	public void testListDeleteCurriculum() {
		//Setting up the authority to execute services.
		this.authenticate("handyworker1");

		//We retrieve a list of all curriculums, and obtain the Id of one of them.
		final Collection<Curriculum> curriculums = this.curriculumService.findAll();
		final int id = curriculums.iterator().next().getId();

		//Using findOne() to retrieve a particular entity and verifying it.
		final Curriculum curriculum = this.curriculumService.findOne(id);

		this.curriculumService.delete(curriculum);

		final Curriculum bbdd = this.curriculumService.findOne(curriculum.getId());
		Assert.isNull(bbdd);
	}
}
