
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.PersonalRecordRepository;
import domain.Curriculum;
import domain.PersonalRecord;

@Service
@Transactional
public class PersonalRecordService {

	//Managed service

	@Autowired
	private PersonalRecordRepository	personalRecordRepository;

	//Supporting service

	@Autowired
	private CurriculumService			curriculumService;

	@Autowired
	private ActorService				actorService;


	//Simple CRUD methods

	public PersonalRecord create(final int curriculumId) {
		final PersonalRecord pr = new PersonalRecord();

		final Curriculum c = this.curriculumService.findOne(curriculumId);
		pr.setCurriculum(c);

		return pr;
	}

	public PersonalRecord findOne(final int id) {
		Assert.notNull(id);

		return this.personalRecordRepository.findOne(id);
	}

	public Collection<PersonalRecord> findAll() {
		return this.personalRecordRepository.findAll();
	}

	public PersonalRecord save(final PersonalRecord pr) {
		Assert.notNull(pr);

		//Assertion that the user modifying this personal record has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == pr.getCurriculum().getHandyWorker().getId());

		//Assertion that the personalRecord link is a linkedIn URL.
		Assert.isTrue(this.checkProfile(pr.getProfile()));

		//Assertion that the personalRecord phone is a valid one.
		Assert.isTrue(this.actorService.checkPhone(pr.getPhone()));

		//Assertion that the personalRecord email is a valid one.
		Assert.isTrue(this.actorService.checkUserEmail(pr.getEmail()));

		final PersonalRecord saved = this.personalRecordRepository.save(pr);

		this.actorService.checkSpam(saved.getName());
		this.actorService.checkSpam(saved.getPhoto());
		this.actorService.checkSpam(saved.getEmail());
		this.actorService.checkSpam(saved.getProfile());

		final Curriculum c = saved.getCurriculum();
		c.setPersonalRecord(saved);
		this.curriculumService.save(c);

		return saved;
	}

	public void delete(final PersonalRecord pr) {
		Assert.notNull(pr);

		//Assertion that the user deleting this personal record has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == pr.getCurriculum().getHandyWorker().getId());
		final Curriculum c = pr.getCurriculum();
		c.setPersonalRecord(null);
		this.curriculumService.save(c);
		this.personalRecordRepository.delete(pr);
	}

	public boolean checkProfile(final String profileLink) {
		Boolean res = false;

		if (profileLink.startsWith("https://www.linkedin.com/in/"))
			res = true;

		return res;
	}
}
