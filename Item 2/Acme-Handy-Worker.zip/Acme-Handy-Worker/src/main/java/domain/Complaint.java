
package domain;

import java.util.Collection;
import java.util.Date;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.URL;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Access(AccessType.PROPERTY)
public class Complaint extends DomainEntity {

	//Attributes

	private String				ticker;
	private Date				moment;
	private String				description;
	private String				attachments;

	//Relationships

	private Customer			customer;
	private FixUpTask			fixUpTask;
	private Referee				referee;
	private Collection<Report>	reports;


	//Getter

	@Column(unique = true)
	@NotBlank
	@Pattern(regexp = "\\d{2}\\d{2}\\d{2}-\\w{6}")
	public String getTicker() {
		return this.ticker;
	}

	@NotNull
	@Past
	@Temporal(TemporalType.TIMESTAMP)
	@DateTimeFormat(pattern = "dd/MM/yyyy HH:mm")
	public Date getMoment() {
		return this.moment;
	}

	@NotBlank
	public String getDescription() {
		return this.description;
	}

	@URL
	public String getAttachments() {
		return this.attachments;
	}

	@NotNull
	@Valid
	@ManyToOne(optional = false)
	public Customer getCustomer() {
		return this.customer;
	}

	@Valid
	@NotNull
	@ManyToOne(optional = false)
	public FixUpTask getFixUpTask() {
		return this.fixUpTask;
	}

	@Valid
	@ManyToOne(optional = true)
	public Referee getReferee() {
		return this.referee;
	}

	@Valid
	@NotNull
	@OneToMany
	public Collection<Report> getReports() {
		return this.reports;
	}

	//Setter

	public void setTicker(final String ticker) {
		this.ticker = ticker;
	}

	public void setMoment(final Date moment) {
		this.moment = moment;
	}

	public void setDescription(final String description) {
		this.description = description;
	}

	public void setAttachments(final String attachments) {
		this.attachments = attachments;
	}

	public void setCustomer(final Customer customer) {
		this.customer = customer;
	}

	public void setFixUpTask(final FixUpTask fixUpTask) {
		this.fixUpTask = fixUpTask;
	}

	public void setReferee(final Referee referee) {
		this.referee = referee;
	}

	public void setReports(final Collection<Report> reports) {
		this.reports = reports;
	}
}
