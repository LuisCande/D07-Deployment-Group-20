
package controllers.customer;

import java.util.ArrayList;
import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.ApplicationService;
import services.CategoryService;
import services.FixUpTaskService;
import services.WarrantyService;
import controllers.AbstractController;
import domain.Application;
import domain.Category;
import domain.Customer;
import domain.FixUpTask;
import domain.Warranty;

@Controller
@RequestMapping("fixUpTask/customer")
public class FixUpTaskCustomerController extends AbstractController {

	//Services

	@Autowired
	private FixUpTaskService	fixUpTaskService;

	@Autowired
	private ActorService		actorService;

	@Autowired
	private WarrantyService		warrantyService;

	@Autowired
	private CategoryService		categoryService;

	@Autowired
	private ApplicationService	applicationService;


	//Creation
	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create() {
		final ModelAndView result;
		FixUpTask fixUpTask;

		fixUpTask = this.fixUpTaskService.create();
		result = this.createEditModelAndView(fixUpTask);

		return result;
	}
	//Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int fixUpTaskId) {
		final ModelAndView result;
		final FixUpTask fixUpTask = this.fixUpTaskService.findOne(fixUpTaskId);

		Assert.notNull(fixUpTask);

		result = this.createEditModelAndView(fixUpTask);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final FixUpTask fixUpTask, final BindingResult binding) {
		ModelAndView result;
		FixUpTask saved;

		final Collection<Application> validApps = this.applicationService.validApplicationByFixUpTask(fixUpTask.getId());

		if (binding.hasErrors())
			result = this.createEditModelAndView(fixUpTask);
		else if (!validApps.isEmpty())
			result = this.createEditModelAndView(fixUpTask, "fixUpTask.fixUpTaskHasValidApp.error");
		else
			try {
				saved = this.fixUpTaskService.save(fixUpTask);
				result = new ModelAndView("redirect:/fixUpTask/customer/display.do?fixUpTaskId=" + saved.getId());
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(fixUpTask, "fixUpTask.commit.error");
			}
		return result;
	}

	//Listing

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		final ModelAndView result;
		Collection<FixUpTask> fixUpTasks;

		final Customer customer = (Customer) this.actorService.findByPrincipal();
		fixUpTasks = customer.getFixUpTasks();

		result = new ModelAndView("fixUpTask/list");
		result.addObject("fixUpTasks", fixUpTasks);
		result.addObject("requestURI", "fixUpTask/customer/list.do");

		return result;
	}

	//Display

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int fixUpTaskId) {
		ModelAndView result;
		FixUpTask fixUpTask;

		fixUpTask = this.fixUpTaskService.findOne(fixUpTaskId);
		result = new ModelAndView("fixUpTask/display");
		result.addObject("fixUpTask", fixUpTask);
		result.addObject("requestURI", "fixUpTask/display.do");

		return result;
	}

	//Delete 
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int fixUpTaskId) {
		ModelAndView result;
		Collection<FixUpTask> fixUpTasks;
		final FixUpTask fixUpTask;

		result = new ModelAndView("fixUpTask/list");

		final Customer c = (Customer) this.actorService.findByPrincipal();
		fixUpTasks = c.getFixUpTasks();

		fixUpTask = this.fixUpTaskService.findOne(fixUpTaskId);
		if (!fixUpTask.getComplaints().isEmpty() || !fixUpTask.getApplications().isEmpty()) {
			result.addObject("requestURI", "fixUpTask/customer/list.do");
			if (!fixUpTask.getComplaints().isEmpty())
				result.addObject("message", "fixUpTask.complaintDelete.error");
			if (!fixUpTask.getApplications().isEmpty())
				result.addObject("message", "fixUpTask.applicationDelete.error");
		} else
			try {
				this.fixUpTaskService.delete(fixUpTask);
				fixUpTasks = c.getFixUpTasks();

				result.addObject("fixUpTasks", fixUpTasks);
				result.addObject("requestURI", "fixUpTask/customer/list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(fixUpTask, "fixUpTask.delete.error");
			}

		return result;
	}

	//Delete POST

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final FixUpTask fixUpTask, final BindingResult binding) {
		ModelAndView result;

		try {
			this.fixUpTaskService.delete(fixUpTask);
			result = new ModelAndView("redirect:/fixUpTask/customer/list.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(fixUpTask, "endorsement.delete.error");
		}
		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final FixUpTask fixUpTask) {
		ModelAndView result;

		result = this.createEditModelAndView(fixUpTask, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final FixUpTask fixUpTask, final String messageCode) {
		ModelAndView result;
		Collection<Warranty> warranties = new ArrayList<Warranty>();
		Collection<Category> categories = new ArrayList<Category>();

		warranties = this.warrantyService.getFinalWarranties();
		categories = this.categoryService.findAll();

		result = new ModelAndView("fixUpTask/edit");
		result.addObject("warranties", warranties);
		result.addObject("categories", categories);
		result.addObject("fixUpTask", fixUpTask);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "fixUpTask/customer/edit.do");

		return result;

	}

}
