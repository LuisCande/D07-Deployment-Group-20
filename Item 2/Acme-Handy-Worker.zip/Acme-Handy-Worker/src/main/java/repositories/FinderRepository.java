
package repositories;

import java.util.Collection;
import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.Finder;
import domain.FixUpTask;

@Repository
public interface FinderRepository extends JpaRepository<Finder, Integer> {

	//Search fixUpTask 
	@Query("select f from FixUpTask f where (f.ticker like %?1% or f.address like %?1% or f.description like %?1%) and (f.maxPrice between ?2 and ?3) and (f.periodStartDate between ?4 and ?5))")
	Collection<FixUpTask> findFixUpTasks(String keyWord, Double minPrice, Double maxPrice, Date dateStart, Date dateEnd);
}
