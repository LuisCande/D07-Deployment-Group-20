
package services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.SponsorRepository;
import security.Authority;
import security.UserAccount;
import domain.Box;
import domain.SocialProfile;
import domain.Sponsor;
import domain.Sponsorship;

@Service
@Transactional
public class SponsorService {

	//Managed repository ---------------------------------

	@Autowired
	private SponsorRepository	sponsorRepository;

	//Supporting services --------------------------------

	@Autowired
	private ActorService		actorService;

	@Autowired
	private BoxService			boxService;


	//Simple CRUD Methods --------------------------------

	public Sponsor create() {

		final Authority a = new Authority();
		a.setAuthority(Authority.SPONSOR);

		final UserAccount account = new UserAccount();
		account.setAuthorities(Arrays.asList(a));
		account.setBanned(false);

		final Sponsor sponsor = new Sponsor();
		sponsor.setSocialProfiles(new ArrayList<SocialProfile>());
		sponsor.setUserAccount(account);
		sponsor.setBoxes(new ArrayList<Box>());
		sponsor.setSuspicious(false);

		sponsor.setSponsorships(new ArrayList<Sponsorship>());

		return sponsor;
	}

	public Collection<Sponsor> findAll() {
		return this.sponsorRepository.findAll();
	}

	public Sponsor findOne(final int id) {
		Assert.notNull(id);

		return this.sponsorRepository.findOne(id);
	}

	public Sponsor save(final Sponsor s) {
		Assert.notNull(s);

		//Assertion to make sure the address is either null or written but not blank spaces.
		Assert.isTrue(!"\\s".equals(s.getAddress()) || s.getAddress() == null);

		//Assertion that the email is valid according to the checkEmail method.
		Assert.isTrue(this.actorService.checkUserEmail(s.getEmail()));

		final Sponsor saved2;
		//Assertion that the user modifying this sponsor has the correct privilege.
		if (s.getId() != 0) {
			Assert.isTrue(this.actorService.findByPrincipal().getId() == s.getId());
			saved2 = this.sponsorRepository.save(s);
		} else {
			final Sponsor saved = this.sponsorRepository.save(s);
			saved.setBoxes(this.boxService.generateDefaultFolders(saved));
			saved2 = this.sponsorRepository.save(saved);
		}

		this.actorService.checkSpam(saved2.getUserAccount().getUsername());
		this.actorService.checkSpam(saved2.getName());
		this.actorService.checkSpam(saved2.getMiddleName());
		this.actorService.checkSpam(saved2.getSurname());
		this.actorService.checkSpam(saved2.getAddress());
		this.actorService.checkSpam(saved2.getPhoto());
		this.actorService.checkSpam(saved2.getEmail());

		return saved2;
	}

	public void delete(final Sponsor sponsor) {
		Assert.notNull(sponsor);

		//Assertion that the user deleting this sponsor has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == sponsor.getId());

		this.sponsorRepository.delete(sponsor);
	}

	//Other methods

	//Returns the collection of suspicious sponsors.
	public Collection<Sponsor> suspiciousSponsors() {
		return this.sponsorRepository.suspiciousSponsors();
	}
}
