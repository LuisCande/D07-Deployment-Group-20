
package controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.FixUpTaskService;
import domain.FixUpTask;
import domain.Warranty;

@Controller
@RequestMapping("warranty")
public class WarrantyController {

	@Autowired
	private FixUpTaskService	fixUpTaskService;


	//Display

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int fixUpTaskId) {
		ModelAndView result;
		Warranty warranty;

		final FixUpTask fixUpTask = this.fixUpTaskService.findOne(fixUpTaskId);
		warranty = fixUpTask.getWarranty();
		result = new ModelAndView("warranty/display");
		result.addObject("warranty", warranty);
		result.addObject("requestURI", "warranty/display.do");

		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Warranty warranty) {
		ModelAndView result;

		result = this.createEditModelAndView(warranty, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Warranty warranty, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("warranty/edit");
		result.addObject("warranty", warranty);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "warranty/edit.do");

		return result;
	}
}
