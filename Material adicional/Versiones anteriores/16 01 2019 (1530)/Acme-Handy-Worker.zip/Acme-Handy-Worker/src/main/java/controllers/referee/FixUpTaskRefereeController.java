
package controllers.referee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.FixUpTaskService;
import controllers.AbstractController;
import domain.FixUpTask;

@Controller
@RequestMapping("fixUpTask/referee")
public class FixUpTaskRefereeController extends AbstractController {

	//Services

	@Autowired
	private FixUpTaskService	fixUpTaskService;


	//Display

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int fixUpTaskId) {
		ModelAndView result;
		FixUpTask fixUpTask;

		fixUpTask = this.fixUpTaskService.findOne(fixUpTaskId);
		result = new ModelAndView("fixUpTask/display");
		result.addObject("fixUpTask", fixUpTask);
		result.addObject("requestURI", "fixUpTask/referee/display.do");

		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final FixUpTask fixUpTask) {
		ModelAndView result;

		result = this.createEditModelAndView(fixUpTask, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final FixUpTask fixUpTask, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("fixUpTask/edit");
		result.addObject("fixUpTask", fixUpTask);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "fixUpTask/referee/edit.do");

		return result;

	}

}
