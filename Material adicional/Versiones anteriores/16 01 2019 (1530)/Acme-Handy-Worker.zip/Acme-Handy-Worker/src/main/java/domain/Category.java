
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
public class Category extends DomainEntity {

	//Attributes

	private String					name;
	private String					nameES;

	//Relationships

	private Category				parent;
	private Collection<Category>	children;


	//Getter

	@NotBlank
	public String getName() {
		return this.name;
	}

	@NotBlank
	public String getNameES() {
		return this.nameES;
	}

	@ManyToOne(optional = true)
	public Category getParent() {
		return this.parent;
	}

	@ElementCollection
	@OneToMany(mappedBy = "parent")
	public Collection<Category> getChildren() {
		return this.children;
	}
	//Setter

	public void setName(final String name) {
		this.name = name;
	}

	public void setNameES(final String nameES) {
		this.nameES = nameES;
	}

	public void setParent(final Category parent) {
		this.parent = parent;
	}

	public void setChildren(final Collection<Category> children) {
		this.children = children;
	}

}
