
package services;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.ComplaintRepository;
import security.Authority;
import domain.Complaint;
import domain.Customer;
import domain.FixUpTask;
import domain.Referee;
import domain.Report;

@Service
@Transactional
public class ComplaintService {

	//Managed repository

	@Autowired
	private ComplaintRepository	complaintRepository;

	//Supporting services
	@Autowired
	private ActorService		actorService;

	@Autowired
	private FixUpTaskService	fixUpTaskService;

	@Autowired
	private ReportService		reportService;


	//Simple CRUD methods

	public Complaint create(final int taskId) {
		final Complaint c = new Complaint();

		final Customer customer = (Customer) this.actorService.findByPrincipal();
		c.setCustomer(customer);
		c.setTicker(this.fixUpTaskService.generateTicker());
		final FixUpTask task = this.fixUpTaskService.findOne(taskId);
		c.setFixUpTask(task);

		c.setMoment(new Date(System.currentTimeMillis() - 1));
		//final Referee ref = this.refereeService.findOne(refId)
		//c.setReferee(ref;) //comentado, al no estar creado el metodo findOne de referee

		c.setReports(new ArrayList<Report>());

		return c;
	}

	public Complaint findOne(final int id) {
		Assert.notNull(id);

		return this.complaintRepository.findOne(id);
	}

	public Collection<Complaint> findAll() {
		return this.complaintRepository.findAll();
	}

	public Complaint save(final Complaint c) {
		Assert.notNull(c);
		//Assertion that the user modifying this complaint has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == c.getCustomer().getId());

		if (c.getId() == 0)
			c.setMoment(new Date(System.currentTimeMillis() - 1));

		final Complaint saved = this.complaintRepository.save(c);

		if (saved.getAttachments() != null)
			this.actorService.checkSpam(c.getAttachments());
		if (saved.getDescription() != null)
			this.actorService.checkSpam(c.getDescription());

		return saved;

	}

	public Complaint saveFromReport(final Complaint c) {
		Assert.notNull(c);
		final Referee r = (Referee) this.actorService.findByPrincipal();
		Complaint saved;

		final Authority authRef = new Authority();
		authRef.setAuthority(Authority.REFEREE);

		//Assertion to make sure that the user modifying this complaint is a referee.
		Assert.isTrue(r.getUserAccount().getAuthorities().contains(authRef));

		if (c.getReferee() == null) {
			c.setReferee(r);
			saved = this.complaintRepository.save(c);
		} else
			saved = c;

		return saved;
	}

	public void delete(final Complaint c) {
		Assert.notNull(c);
		//Assertion that the user deleting this complaint has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == c.getCustomer().getId());

		//Also, we delete the report related with the deleted complaint
		if (!(c.getReports().isEmpty()))
			for (final Report rep : c.getReports())
				this.reportService.delete2(rep);

		this.complaintRepository.delete(c);

	}

	//Other methods

	//The minimum, the minimum, the maximum, the average, and the standard deviation of the number of complaints per fix-up task
	public Double[] minMaxAvgStddevComplaintsPerFixUpTask() {
		return this.complaintRepository.minMaxAvgStddevComplaintsPerFixUpTask();
	}

	//List the complaints that no referee has self-assigned
	public Collection<Complaint> complaintsWithOutReferee() {
		return this.complaintRepository.complaintsWithOutReferee();
	}

}
