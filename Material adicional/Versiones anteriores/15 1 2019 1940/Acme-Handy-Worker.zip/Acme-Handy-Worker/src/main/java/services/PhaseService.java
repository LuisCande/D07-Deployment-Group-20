
package services;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.PhaseRepository;
import domain.Application;
import domain.HandyWorker;
import domain.Phase;

@Service
@Transactional
public class PhaseService {

	//Managed service

	@Autowired
	private PhaseRepository		phaseRepository;

	//Supporting service

	@Autowired
	private ActorService		actorService;
	@Autowired
	private ApplicationService	applicationService;


	//Simple CRUD methods

	public Phase create(final int applicationId) {

		final Phase p = new Phase();

		final HandyWorker hw = (HandyWorker) this.actorService.findByPrincipal();
		final Application a = this.applicationService.findOne(applicationId);
		p.setHandyWorker(hw);
		p.setApplication(a);

		return p;
	}

	public Collection<Phase> findAll() {
		return this.phaseRepository.findAll();
	}

	public Phase findOne(final int id) {
		Assert.notNull(id);

		return this.phaseRepository.findOne(id);
	}

	public Phase save(final Phase phase) {
		Assert.notNull(phase);

		//Assertion that the user saving this note has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == phase.getHandyWorker().getId());

		//Assertion that the user saving this note has the correct privilege.
		Assert.isTrue(phase.getHandyWorker() == phase.getApplication().getHandyWorker());

		//Assertion that start moment must be after task start moment
		Assert.isTrue(phase.getStartMoment().after(phase.getApplication().getFixUpTask().getPeriodStartDate()));

		//Assertion that period end moment must be before task end moment
		Assert.isTrue(phase.getEndMoment().before(phase.getApplication().getFixUpTask().getPeriodEndDate()));

		final Phase saved = this.phaseRepository.save(phase);
		if (phase.getId() == 0) {
			final Application application = phase.getApplication();
			final Collection<Phase> phases = application.getPhases();
			phases.add(saved);
			application.setPhases(phases);
			this.applicationService.saveFromPhase(application);
		}

		this.actorService.checkSpam(saved.getTitle());
		this.actorService.checkSpam(saved.getDescription());

		return saved;
	}

	public void delete(final Phase phase) {
		Assert.notNull(phase);

		//Assertion that the user deleting this note has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getId() == phase.getHandyWorker().getId());

		this.phaseRepository.delete(phase);
	}

}
