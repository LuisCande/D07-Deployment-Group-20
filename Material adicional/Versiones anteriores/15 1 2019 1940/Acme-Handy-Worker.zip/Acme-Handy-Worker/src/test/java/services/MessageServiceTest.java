
package services;

import java.util.ArrayList;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Actor;
import domain.Application;
import domain.Box;
import domain.Message;
import domain.Priority;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class MessageServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private MessageService		messageService;

	@Autowired
	private ActorService		actorService;

	@Autowired
	private BoxService			boxService;

	@Autowired
	private ApplicationService	applicationService;


	//Tests

	@Test
	public void testCreateMessage() {

		//Setting up the authority to execute services.
		this.authenticate("customer1");

		final Box box = this.boxService.getSystemBoxByName(this.actorService.findByPrincipal().getId(), "In box");

		//Using create() to initialise a new entity.
		final Message message = this.messageService.create();
		final Actor recipient = this.actorService.findOne(8549); //id customer2
		message.setSubject("testMessage");
		message.setBody("This is a test message");
		message.setPriority(Priority.NEUTRAL);
		message.setRecipient(recipient);

		final Collection<Box> messageBoxes = new ArrayList<Box>();
		final Box recipientBox = this.boxService.getSystemBoxByName(recipient.getId(), "Out box");
		messageBoxes.add(box);
		messageBoxes.add(recipientBox);
		message.setBoxes(messageBoxes);

		final Message saved = this.messageService.save(message);
		final Message bbdd = this.messageService.findOne(saved.getId());
		Assert.notNull(bbdd);

	}

	@Test
	public void testMoveMessage() {
		//Setting up the authority to execute services.
		this.authenticate("customer1");

		//We retrieve a list of all messages, and obtain the Id of one of them.
		final Actor a = this.actorService.findByPrincipal();
		final Box b = this.boxService.getSystemBoxByName(a.getId(), "Out box");

		//Using findOne() to retrieve a particular entity and verifying it.
		final Collection<Message> msgs = b.getMessages();
		final Message message = msgs.iterator().next();
		Assert.notNull(message);

		//Using delete() to delete the entity we retrieved.
		this.messageService.delete(message);

		//Verifying the entity has been removed from the database.
		final Message bbdd = this.messageService.findOne(message.getId());
		Assert.notNull(bbdd);
	}

	@Test
	public void testDeleteMessage() {
		//Setting up the authority to execute services.
		this.authenticate("handyWorker1");

		//We retrieve a list of all messages, and obtain the Id of one of them.
		final Actor a = this.actorService.findByPrincipal();
		final Box b = this.boxService.getSystemBoxByName(a.getId(), "Trash box");
		//Using findOne() to retrieve a particular entity and verifying it.
		final Collection<Message> msgs = b.getMessages();
		final Message message = msgs.iterator().next();
		Assert.notNull(message);

		//Using delete() to delete the entity we retrieved.
		this.messageService.delete(message);
		//Verifying the entity has been removed from the database.
		final Message bbdd = this.messageService.findOne(message.getId());
		Assert.isNull(bbdd);
	}

	@Test
	public void testApplicationStatusNotification() {
		//Setting up the authority to execute services.
		this.authenticate("customer1");

		//Sending a notification to the two necessary actors.
		final Application app = this.applicationService.findOne(8693);
		Assert.notNull(app);
		this.messageService.applicationStatusNotification(app);

		//Verifying there are messages in the database.
		Assert.notEmpty(this.messageService.findAll());
	}
}
