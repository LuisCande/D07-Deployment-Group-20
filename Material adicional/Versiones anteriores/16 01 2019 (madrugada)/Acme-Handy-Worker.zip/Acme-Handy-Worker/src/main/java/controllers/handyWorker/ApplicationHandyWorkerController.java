
package controllers.handyWorker;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.ApplicationService;
import controllers.AbstractController;
import domain.Application;
import domain.FixUpTask;
import domain.HandyWorker;

@Controller
@RequestMapping("application/handyWorker")
public class ApplicationHandyWorkerController extends AbstractController {

	//Services

	@Autowired
	private ApplicationService	applicationService;

	@Autowired
	private ActorService		actorService;


	//Listing

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		final ModelAndView result;
		final Collection<Application> applications;
		//final HandyWorker handyWorker;
		//final Date futureDate = LocalDate.now().plusMonths(1).toDate();

		applications = ((HandyWorker) this.actorService.findByPrincipal()).getApplications();

		result = new ModelAndView("application/list");
		result.addObject("applications", applications);
		//result.addObject("futureDate", futureDate);
		result.addObject("requestURI", "application/handyWorker/list.do");

		return result;
	}
	//Creation

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int fixUpTaskId) {
		final ModelAndView result;
		Application application;

		application = this.applicationService.create(fixUpTaskId);
		result = this.createEditModelAndView(application);

		return result;
	}

	//Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int varId) {
		final ModelAndView result;
		Application application;

		application = this.applicationService.findOne(varId);
		Assert.notNull(application);
		result = this.createEditModelAndView(application);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Application application, final BindingResult binding) {
		ModelAndView result;

		if (binding.hasErrors())
			result = this.createEditModelAndView(application);
		else if (application.getOfferedPrice() > application.getFixUpTask().getMaxPrice())
			result = this.createEditModelAndView(application, "application.price.error");
		else
			try {
				this.applicationService.save(application);
				result = new ModelAndView("redirect:/application/handyWorker/list.do");
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(application, "application.commit.error");
			}
		return result;
	}

	//Delete 
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int varId) {
		ModelAndView result;
		Collection<Application> applications;
		Application application;
		application = this.applicationService.findOne(varId);
		final FixUpTask fu = application.getFixUpTask();

		result = new ModelAndView("application/list");

		applications = fu.getApplications();
		try {
			this.applicationService.delete(application);
			applications = fu.getApplications();

			result.addObject("applications", applications);
			result.addObject("requestURI", "application/handyWorker/list.do");

		} catch (final Throwable oops) {
			result = this.createEditModelAndView(application, "report.delete.error");
		}

		return result;
	}
	//Delete POST
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Application application, final BindingResult binding) {
		ModelAndView result;

		try {
			this.applicationService.delete(application);
			result = new ModelAndView("redirect:list.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(application, "application.commit.error");
		}
		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Application application) {
		ModelAndView result;

		result = this.createEditModelAndView(application, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Application application, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("application/edit");
		result.addObject("application", application);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "application/handyWorker/edit.do");

		return result;

	}
}
