
package controllers.referee;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.ComplaintService;
import services.FixUpTaskService;
import services.RefereeService;
import controllers.AbstractController;
import domain.Complaint;
import domain.FixUpTask;
import domain.Referee;

@Controller
@RequestMapping("complaint/referee")
public class ComplaintRefereeController extends AbstractController {

	//Services

	@Autowired
	private ComplaintService	complaintService;

	@Autowired
	private ActorService		actorService;
	@Autowired
	private RefereeService		refereeService;
	@Autowired
	private FixUpTaskService	fixUpTaskService;


	//Listing

	@RequestMapping(value = "/listNA", method = RequestMethod.GET)
	public ModelAndView listNonAssign() {
		final ModelAndView result;
		Collection<Complaint> complaints;

		//Listado de complaints sin referee asignado
		complaints = this.complaintService.complaintsWithOutReferee();

		result = new ModelAndView("complaint/list");
		result.addObject("complaints", complaints);
		result.addObject("requestURI", "complaint/referee/listNA.do");

		return result;
	}

	@RequestMapping(value = "/listA", method = RequestMethod.GET)
	public ModelAndView listAssign() {
		final ModelAndView result;
		Collection<Complaint> complaints;

		//Listado de complaints con referee asignado

		final Referee referee = this.refereeService.findOne(this.actorService.findByPrincipal().getId());
		complaints = referee.getComplaints();

		result = new ModelAndView("complaint/list");
		result.addObject("complaints", complaints);
		result.addObject("requestURI", "complaint/referee/listA.do");

		return result;
	}

	@RequestMapping(value = "/listByFixUpTask", method = RequestMethod.GET)
	public ModelAndView listByFixUpTask(@RequestParam final int fixUpTaskId) {
		final ModelAndView result;
		Collection<Complaint> complaints;

		final FixUpTask fixUpTask = this.fixUpTaskService.findOne(fixUpTaskId);
		complaints = fixUpTask.getComplaints();

		result = new ModelAndView("complaint/list");
		result.addObject("complaints", complaints);
		result.addObject("requestURI", "complaint/referee/listByFixUpTask.do");

		return result;
	}

	//Display

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int complaintId) {
		ModelAndView result;
		Complaint complaint;

		complaint = this.complaintService.findOne(complaintId);
		result = new ModelAndView("complaint/display");
		result.addObject("complaint", complaint);
		result.addObject("requestURI", "complaint/display.do");

		return result;
	}

	//	//Creation
	//
	//	@RequestMapping(value = "/create", method = RequestMethod.GET)
	//	public ModelAndView create(@RequestParam final int fixUpTaskId) {
	//		final ModelAndView result;
	//		Complaint complaint;
	//
	//		complaint = this.complaintService.create(fixUpTaskId);
	//		result = this.createEditModelAndView(complaint);
	//
	//		return result;
	//	}
	//
	//	//Edition
	//
	//	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	//	public ModelAndView edit(@RequestParam final int varId) {
	//		final ModelAndView result;
	//		Complaint complaint;
	//
	//		complaint = this.complaintService.findOne(varId);
	//		Assert.notNull(complaint);
	//		result = this.createEditModelAndView(complaint);
	//
	//		return result;
	//	}
	//
	//	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	//	public ModelAndView save(@Valid final Complaint complaint, final BindingResult binding) {
	//		ModelAndView result;
	//
	//		if (binding.hasErrors())
	//			result = this.createEditModelAndView(complaint);
	//		else
	//			try {
	//				this.complaintService.save(complaint);
	//				result = new ModelAndView("redirect:list.do");
	//			} catch (final Throwable oops) {
	//				result = this.createEditModelAndView(complaint, "complaint.commit.error");
	//			}
	//		return result;
	//	}
	//
	//	//Delete (No existe en customer)
	//

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Complaint complaint) {
		ModelAndView result;

		result = this.createEditModelAndView(complaint, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Complaint complaint, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("complaint/edit");
		result.addObject("complaint", complaint);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "complaint/customer/edit.do");

		return result;

	}

}
