
package services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import repositories.CustomerRepository;
import security.Authority;
import security.UserAccount;
import domain.Box;
import domain.Complaint;
import domain.Customer;
import domain.Endorsement;
import domain.FixUpTask;
import domain.SocialProfile;

@Service
@Transactional
public class CustomerService {

	//Managed repository

	@Autowired
	private CustomerRepository	customerRepository;

	//Supporting services

	@Autowired
	private ActorService		actorService;

	@Autowired
	private BoxService			boxService;


	//Simple CRUD methods

	public Customer create() {
		final Authority a = new Authority();
		a.setAuthority(Authority.CUSTOMER);

		final UserAccount account = new UserAccount();
		account.setAuthorities(Arrays.asList(a));
		account.setBanned(false);

		final Customer c = new Customer();
		c.setSocialProfiles(new ArrayList<SocialProfile>());
		c.setUserAccount(account);
		c.setSuspicious(false);

		c.setFixUpTasks(new ArrayList<FixUpTask>());
		c.setComplaints(new ArrayList<Complaint>());
		c.setEndorsements(new ArrayList<Endorsement>());
		c.setBoxes(new ArrayList<Box>());

		return c;
	}

	public Customer findOne(final int id) {
		Assert.notNull(id);

		return this.customerRepository.findOne(id);
	}

	public Collection<Customer> findAll() {
		return this.customerRepository.findAll();
	}

	public Customer save(final Customer c) {
		Assert.notNull(c);

		//Assertion to make sure the address is either null or written but not blank spaces.
		Assert.isTrue(!"\\s".equals(c.getAddress()) || c.getAddress() == null);

		//Assertion that the email is valid according to the checkEmail method.
		Assert.isTrue(this.actorService.checkUserEmail(c.getEmail()));

		//Assertion to check that the address isn't just a white space.
		Assert.isTrue(this.actorService.checkAddress(c.getAddress()));

		//Assertion that the phone is valid according to the checkPhone method.
		Assert.isTrue(this.actorService.checkPhone(c.getPhone()));

		Customer saved2;

		if (c.getId() != 0) {
			Assert.isTrue(this.actorService.findByPrincipal().getId() == c.getId());
			saved2 = this.customerRepository.save(c);
		} else {
			final Customer saved = this.customerRepository.save(c);
			this.actorService.hashPassword(saved);
			saved.setBoxes(this.boxService.generateDefaultFolders(saved));
			saved2 = this.customerRepository.save(saved);
		}

		return saved2;
	}

	public Customer saveFromAdmin(final Customer c) {
		Assert.notNull(c);

		final Authority authAdmin = new Authority();
		authAdmin.setAuthority(Authority.ADMIN);

		final Customer saved2;
		//Assertion that the user modifying this customer has the correct privilege.
		Assert.isTrue(this.actorService.findByPrincipal().getUserAccount().getAuthorities().contains(authAdmin));

		saved2 = this.customerRepository.save(c);

		return saved2;
	}

	public void delete(final Customer c) {
		Assert.notNull(c);

		this.customerRepository.delete(c);
	}

	//Other methods

	//The listing of customers with at least one endorsement.
	public Collection<Customer> getCustomersWithAtLeastOneEndorsement() {
		return this.customerRepository.getCustomersWithAtLeastOneEndorsement();
	}

	//The top-three customers in terms of complaints.
	public Collection<Customer> topThreeCustomersInTermsOfComplaints() {
		final ArrayList<Customer> customerList = (ArrayList<Customer>) this.customerRepository.topCustomersInTermsOfComplaints();
		final ArrayList<Customer> top3 = new ArrayList<Customer>(customerList.subList(customerList.size() - 3, customerList.size()));
		return top3;
	}

	//The listing of customers who have published at least 10% more fix-up tasks than the average, ordered by number of applications
	public Collection<Customer> listCustomersTenPerCentMore() {
		return this.customerRepository.listCustomersTenPerCentMore();
	}

	//The listing of endorsable customers for a certain handy worker.
	public Collection<Customer> endorsableCustomersForHandyWorker(final int id) {
		return this.customerRepository.endorsableCustomersForHandyWorker(id);
	}

	//Returns the collection of suspicious customers.
	public Collection<Customer> suspiciousCustomer() {
		return this.customerRepository.suspiciousCustomers();
	}
}
