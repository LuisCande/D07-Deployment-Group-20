
package controllers.customer;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.ActorService;
import services.EndorsementService;
import controllers.AbstractController;
import domain.Customer;
import domain.Endorsement;

@Controller
@RequestMapping("endorsement/customer")
public class EndorsementCustomerController extends AbstractController {

	//Services

	@Autowired
	private EndorsementService	endorsementService;

	@Autowired
	private ActorService		actorService;


	//Creation

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(@RequestParam final int actorId) {
		final ModelAndView result;
		Endorsement endorsement;

		endorsement = this.endorsementService.create(actorId);
		result = this.createEditModelAndView(endorsement);

		return result;
	}
	//Edition

	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int endorsementId) {
		final ModelAndView result;
		final Endorsement endorsement = this.endorsementService.findOne(endorsementId);
		Assert.notNull(endorsement);
		result = this.createEditModelAndView(endorsement);

		return result;
	}

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView save(@Valid final Endorsement endorsement, final BindingResult binding) {
		ModelAndView result;
		Endorsement saved;

		if (binding.hasErrors())
			result = this.createEditModelAndView(endorsement);
		else
			try {
				saved = this.endorsementService.save(endorsement);
				result = new ModelAndView("redirect:/endorsement/customer/display.do?endorsementId=" + saved.getId());
			} catch (final Throwable oops) {
				result = this.createEditModelAndView(endorsement, "endorsement.commit.error");
			}
		return result;
	}

	//List

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		final ModelAndView result;
		Collection<Endorsement> endorsements;

		final Customer c = (Customer) this.actorService.findByPrincipal();
		endorsements = c.getEndorsements();

		result = new ModelAndView("endorsement/list");
		result.addObject("endorsements", endorsements);
		result.addObject("requestURI", "endorsement/customer/list.do");

		return result;
	}

	//Display

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int endorsementId) {
		final ModelAndView result;

		final Endorsement endorsement = this.endorsementService.findOne(endorsementId);
		Assert.notNull(endorsement);

		result = new ModelAndView("endorsement/display");
		result.addObject("endorsement", endorsement);
		result.addObject("requestURI", "endorsement/customer/display.do");

		return result;
	}

	//Delete 
	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public ModelAndView delete(@RequestParam final int endorsementId) {
		ModelAndView result;
		Collection<Endorsement> endorsements;
		Endorsement endorsement;

		result = new ModelAndView("endorsement/list");

		final Customer c = (Customer) this.actorService.findByPrincipal();
		endorsements = c.getEndorsements();

		endorsement = this.endorsementService.findOne(endorsementId);
		try {
			this.endorsementService.delete(endorsement);
			endorsements = c.getEndorsements();

			result.addObject("endorsements", endorsements);
			result.addObject("requestURI", "endorsement/customer/list.do");

		} catch (final Throwable oops) {
			result = this.createEditModelAndView(endorsement, "endorsement.delete.error");
		}

		return result;
	}

	//Delete POST

	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(final Endorsement endorsement, final BindingResult binding) {
		ModelAndView result;

		try {
			this.endorsementService.delete(endorsement);
			result = new ModelAndView("redirect:/endorsement/customer/list.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(endorsement, "endorsement.delete.error");
		}
		return result;
	}

	//Ancillary methods

	protected ModelAndView createEditModelAndView(final Endorsement endorsement) {
		ModelAndView result;

		result = this.createEditModelAndView(endorsement, null);

		return result;
	}

	protected ModelAndView createEditModelAndView(final Endorsement endorsement, final String messageCode) {
		ModelAndView result;

		result = new ModelAndView("endorsement/edit");
		result.addObject("endorsement", endorsement);
		result.addObject("message", messageCode);
		result.addObject("requestURI", "endorsement/customer/edit.do");

		return result;

	}
}
