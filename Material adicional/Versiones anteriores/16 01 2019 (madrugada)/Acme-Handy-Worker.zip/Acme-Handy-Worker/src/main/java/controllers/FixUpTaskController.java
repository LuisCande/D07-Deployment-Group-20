
package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.CustomerService;
import services.FixUpTaskService;
import domain.Customer;
import domain.FixUpTask;

@Controller
@RequestMapping("fixUpTask")
public class FixUpTaskController extends AbstractController {

	//Services

	@Autowired
	private FixUpTaskService	fixUpTaskService;

	@Autowired
	private CustomerService		customerService;


	//	@Autowired
	//	private CategoryService		categoryService;

	//Listing

	@RequestMapping(value = "/listByCustomer", method = RequestMethod.GET)
	public ModelAndView listByComplaint(@RequestParam final int customerId) {
		final ModelAndView result;
		final Collection<FixUpTask> fixUpTasks;

		final Customer customer = this.customerService.findOne(customerId);
		fixUpTasks = customer.getFixUpTasks();

		result = new ModelAndView("fixUpTask/list");
		result.addObject("fixUpTasks", fixUpTasks);
		result.addObject("requestURI", "fixUpTask/listByCustomer.do");

		return result;
	}

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		final ModelAndView result;
		Collection<FixUpTask> fixUpTasks;

		fixUpTasks = this.fixUpTaskService.findAll();

		result = new ModelAndView("fixUpTask/list");
		result.addObject("fixUpTasks", fixUpTasks);
		result.addObject("requestURI", "fixUpTask/list.do");

		return result;
	}

	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int fixUpTaskId) {
		ModelAndView result;
		FixUpTask fixUpTask;

		fixUpTask = this.fixUpTaskService.findOne(fixUpTaskId);

		result = new ModelAndView("fixUpTask/display");
		result.addObject("fixUpTask", fixUpTask);
		result.addObject("requestURI", "fixUpTask/display.do");

		return result;
	}

}
