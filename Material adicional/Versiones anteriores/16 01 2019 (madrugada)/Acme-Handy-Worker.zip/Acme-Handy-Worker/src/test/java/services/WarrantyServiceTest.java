
package services;

import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Warranty;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class WarrantyServiceTest extends AbstractTest {

	//Service under test
	@Autowired
	private WarrantyService	warrantyService;


	//Test
	@Test
	public void testCreateWarranty() {

		//Setting up the authority to execute services.
		this.authenticate("admin");

		//Using create() to initialise a new entity. 
		final Warranty warranty = this.warrantyService.create();
		warranty.setTitle("Title 1");
		warranty.setTerms("Terms 1");
		warranty.setLaws("Laws 1");

		final Warranty saved = this.warrantyService.save(warranty, true);
		final Warranty bbdd = this.warrantyService.findOne(saved.getId());
		Assert.notNull(bbdd);
	}

	@Test
	public void testListDeleteWarranty() {
		//Setting up the authority to execute services.
		this.authenticate("admin");

		//We retrieve a list of all Tutorials, and obtain the Id of one of them.
		Collection<Warranty> warranties = this.warrantyService.findAll();

		//Using findOne() to retrieve a particular entity and verifying it.
		final Warranty warranty = this.warrantyService.findOne(8596);//Id de warranty que tenga finalMode a false
		Assert.notNull(warranty);

		//Using delete() to delete the entity we retrieved.
		this.warrantyService.delete(warranty);

		//Verifying the entity has been removed from the database.
		warranties = this.warrantyService.findAll();
		Assert.isTrue(!warranties.contains(warranty));
	}
}
