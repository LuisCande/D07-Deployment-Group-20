
package services;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import utilities.AbstractTest;
import domain.Sponsor;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {
	"classpath:spring/datasource.xml", "classpath:spring/config/packages.xml"
})
@Transactional
public class SponsorServiceTest extends AbstractTest {

	//Service under test

	@Autowired
	private SponsorService	sponsorService;


	//Test
	@Test
	public void testCreateSponsor() {

		//Setting up the authority to execute services.

		//Using create() to initialise a new entity. Necessary Id's taken from populated database.

		final Sponsor sponsor = this.sponsorService.create();

		sponsor.setName("Luis");
		sponsor.setSurname("Gil");
		sponsor.setEmail("luigilgue@alum.us.es");
		sponsor.setPhone("666696969");
		sponsor.setAddress("C/ Falsa 32");
		sponsor.getUserAccount().setUsername("SponLu");
		sponsor.getUserAccount().setPassword("12345678");

		final Sponsor saved = this.sponsorService.save(sponsor);
		final Sponsor bbdd = this.sponsorService.findOne(saved.getId());
		Assert.notNull(bbdd);
	}
}
